class CRectangulo{
    constructor(Alto,Ancho){
        this.Alto = Alto;
        this.Ancho = Ancho;
    }
    CalcularArea(Alto,Ancho){
        return Alto*Ancho;
    }
}